# E-Waste Guardian — Python-only prototype

A mobile-responsive Streamlit prototype for a 2nd-year AIDS engineering sustainability project.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the Streamlit URL on a phone connected to the same network, or deploy the project to Streamlit Community Cloud for a public URL.

## Features
- Device assessment
- Explainable Python rule-based recommendation
- Sell / Exchange, Repair / Reuse, Recycle paths
- Data-safety checklist
- Local search for selling/recycling options
- SQLite history and impact dashboard
- E-waste awareness guide
